#!/bin/bash
k=10
mkdir ./$k.mer.counts
mkdir ./$k.out
for i in *.fasta
do
  ~/KMC3/kmc -m12 -ci0 -k$k -fa $i ./out/$i.out tmp
  ~/KMC3/kmc_dump ./out/$i.out ./$k.mer.counts/$i.txt
done
rm -rf $k.out
